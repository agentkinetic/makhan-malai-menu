import { createFileRoute, Link } from '@tanstack/react-router'

export const Route = createFileRoute('/menu')({
  head: () => ({
    meta: [
      {
        title: 'Menu | Makhan Malai Restaurant',
      },
    ],
  }),
  component: MenuPage,
})

function MenuPage() {
  const categories = [
    {
      name: "Shinwari Cuisine Chicken",
      items: [
        { name: "Shinwari Chicken Karahi", price: "25/45 AED", description: "Fresh chicken karahi cooked with tomatoes, salt, green chilies & black pepper (Half/Full)" },
        { name: "Chicken Lahori Karahi", price: "27/50 AED", description: "Fresh chicken cooked with traditional ingredients, cream & butter (Half/Full)" },
        { name: "Chicken White Special Karahi", price: "27/50 AED", description: "Fresh chicken cooked with chef's special ingredients, fresh butter and yoghurt (Half/Full)" },
        { name: "Lahori Charga", price: "8/15/28 AED", description: "Whole chicken steam roast with chef's special recipe (Per Person / Half / Full)" },
      ]
    },
    {
      name: "Tandoor Specialties",
      items: [
        { name: "Roti", price: "1.25 AED", description: "Traditional whole wheat bread" },
        { name: "Sada Nan", price: "1.5 AED", description: "Freshly baked plain naan" },
        { name: "Lahori Kulcha", price: "2 AED", description: "Soft, leavened bread with sesame seeds" },
        { name: "Kandhari Nan", price: "3 AED", description: "Long, traditional Afghan style naan" },
        { name: "Roghni Nan", price: "4 AED", description: "Rich naan topped with butter and sesame" },
        { name: "Garlic Nan", price: "4 AED", description: "Freshly baked naan with garlic and herbs" },
        { name: "Butter Nan", price: "4 AED", description: "Soft naan brushed with premium butter" },
        { name: "Family Nan Basket", price: "10 AED", description: "Assorted basket for the whole family" },
      ]
    },
    {
      name: "Tempting Treats & Beverages",
      items: [
        { name: "Traditional Lahori Badami Kheer", price: "5 AED", description: "National dessert of Pakistan: slow-cooked rice, milk, sugar & almonds" },
        { name: "Fresh Lassi (Saltish/Sweet)", price: "5 AED", description: "Cooling, refreshing yogurt drink" },
        { name: "Fresh Lime with Soft Drinks", price: "4 AED", description: "Freshly squeezed limes mixed with your choice of soft drink" },
      ]
    },
    {
      name: "Rice Delights",
      items: [
        { name: "Al Rehman Biryani - Chicken", price: "13 AED", description: "Famous Karachi style chicken biryani with special basmati rice" },
        { name: "Al Rehman Biryani - Mutton", price: "20 AED", description: "Most popular mutton biryani with aromatic spices" },
        { name: "Al Rehman Biryani - Rice solo", price: "7 AED", description: "Flavorful biryani rice served without meat" },
        { name: "White Rice", price: "3 AED", description: "Steam cooked premium basmati rice" },
      ]
    },
    {
      name: "Handi Delicacies",
      items: [
        { name: "Chicken Irani Handi", price: "26 AED", description: "Boneless cubes in butter & cream with Khapra, Capsicum & Cheese" },
        { name: "Butter Chicken", price: "27 AED", description: "Rich gravy of boneless cubes in fresh butter & traditional desi spices" },
        { name: "Chicken Achari Handi", price: "27 AED", description: "Boneless cubes in fresh butter & cream with tangy fresh pickle" },
        { name: "Chicken Chatkhara Handi", price: "25 AED", description: "Boneless cubes cooked with special green recipe, butter & cream" },
        { name: "Chicken Kashmiri Handi", price: "26 AED", description: "Boneless cubes in fresh butter & cream with Kashmiri spices & herbs" },
      ]
    },
    {
      name: "Breakfast Bliss",
      items: [
        { name: "Plain Paratha", price: "1.5 AED", description: "Freshly made crispy flatbread" },
        { name: "Aloo Paratha", price: "3 AED", description: "Paratha stuffed with spiced potatoes" },
        { name: "Qeema Paratha", price: "4 AED", description: "Paratha stuffed with minced meat" },
        { name: "Lahori Chana", price: "3/5 AED", description: "Authentic Lahori style chickpeas (Half/Full)" },
        { name: "Vegetable", price: "3/5 AED", description: "Fresh seasonal vegetable dish (Half/Full)" },
        { name: "Mutton Paya", price: "10 AED", description: "Traditional slow-cooked mutton trotters" },
        { name: "Alo Qeema", price: "5/10 AED", description: "Minced meat with potatoes (Half/Full)" },
        { name: "Chicken Haleem", price: "6/11 AED", description: "Slow-cooked savory porridge of meat and grains (Half/Full)" },
        { name: "Beef Nihari", price: "7/13 AED", description: "Rich, slow-cooked beef stew with marrow (Half/Full)" },
        { name: "Omlete", price: "2.5 AED", description: "Fluffy egg omelette with herbs" },
        { name: "Egg Full Fry / Half Fry", price: "2 AED", description: "Eggs cooked to your preference" },
        { name: "Boiled Egg", price: "1 AED", description: "Perfectly boiled egg" },
        { name: "Egg Paratha Roll", price: "5 AED", description: "Crispy paratha rolled with egg" },
        { name: "Chicken Paratha Roll", price: "5 AED", description: "Crispy paratha rolled with spiced chicken" },
      ]
    },
    {
      name: "Assorted Delicacies",
      items: [
        { name: "Dal Chana", price: "5/7 AED", description: "Asian lentil dish with onion, tomatoes, ginger, garlic & spices (Half/Full)" },
        { name: "Dal Mash", price: "5/7 AED", description: "White urid lentils with onion, tomato masala & spices (Half/Full)" },
        { name: "Shahi Dal Mash", price: "10 AED", description: "Premium dal mash made with chef's special spices" },
        { name: "Palak Paneer", price: "7/12 AED", description: "Paneer cubes in a smooth & thick spinach gravy (Half/Full)" },
        { name: "Mixed Vegetables", price: "6/10 AED", description: "Fresh carrots, green peas, potato and cauliflower (Half/Full)" },
      ]
    },
    {
      name: "Royal Karahis (Mutton)",
      items: [
        { name: "Shinwari Mutton Karahi", price: "45 AED", description: "Mutton cooked in its own fat with tomatoes and green chilies" },
        { name: "Mutton Dumpokht", price: "48 AED", description: "Traditional slow-cooked meat and rice from the mountains" },
      ]
    },
  ]

  return (
    <div className="min-h-screen bg-[#fffcf5] pb-20">
      <header className="bg-red-700 text-white py-12 px-4 shadow-lg relative overflow-hidden text-center">
        <Link to="/" className="absolute top-6 left-6 bg-white/20 hover:bg-white/30 backdrop-blur-md p-2 rounded-full transition-all">
          ← Back
        </Link>
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl font-serif font-black italic mb-2">Our Menu</h1>
          <p className="text-red-100 font-medium tracking-widest uppercase text-sm">Authentic Tastes of the Subcontinent</p>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 mt-12 space-y-16">
        {categories.map((category, idx) => (
          <section key={idx} className="relative">
            <div className="flex items-center gap-4 mb-8">
               <h2 className="text-3xl font-serif font-black text-stone-900 italic">{category.name}</h2>
               <div className="flex-1 h-[2px] bg-amber-400 opacity-30"></div>
            </div>
            <div className="grid gap-6">
              {category.items.map((item, itemIdx) => (
                <div key={itemIdx} className="bg-white p-6 rounded-2xl shadow-sm border border-stone-100 hover:border-amber-200 hover:shadow-md transition-all flex justify-between items-center group">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-stone-800 mb-1 group-hover:text-red-600 transition-colors">{item.name}</h3>
                    <p className="text-stone-500 text-sm font-medium">{item.description}</p>
                  </div>
                  <div className="text-right ml-6">
                    <span className="text-xl font-black text-stone-900 whitespace-nowrap">{item.price}</span>
                  </div>
                </div>
              ))}
            </div>
          </section>
        ))}
      </main>

      <footer className="mt-20 text-center px-4">
        <div className="max-w-md mx-auto bg-amber-100 p-8 rounded-3xl border-2 border-amber-200 shadow-xl">
           <p className="font-bold text-stone-800 italic mb-4">Prices may vary slightly based on seasonal availability.</p>
           <a href="tel:0505598443" className="bg-red-600 text-white px-8 py-3 rounded-xl font-black shadow-lg hover:bg-red-700 transition-colors inline-block">
             Call to Order Now
           </a>
        </div>
      </footer>
    </div>
  )
}
