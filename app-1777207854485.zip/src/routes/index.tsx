import { createFileRoute, Link } from '@tanstack/react-router'
import { useSuspenseQuery } from '@tanstack/react-query'
import { convexQuery } from '@convex-dev/react-query'
import { useMutation } from 'convex/react'
import { api } from '../../convex/_generated/api'
import * as React from 'react'
import { useState } from 'react'

export const Route = createFileRoute('/')({
  head: () => ({
    meta: [
      {
        title: 'Makhan Malai | Authentic Karachi Biryani & Shinwari Karahi',
      },
    ],
  }),
  component: Home,
})

function Home() {
  const googleMapsUrl = "https://www.google.com/maps/dir/?api=1&destination=Makhan+Malai+Restaurant+Musaffah+Abu+Dhabi"
  const menuHighlights = [
    { name: "Mutton Dumpokht", description: "Slow-cooked tender mutton with traditional spices.", color: "bg-red-50 border-red-200 text-red-900" },
    { name: "Karachi's Al-Rehman Biryani", description: "Authentic spicy and aromatic Karachi style biryani.", color: "bg-amber-50 border-amber-200 text-amber-900" },
    { name: "Shinwari Mutton Karahi", description: "Traditional Peshawari style karahi cooked with minimal spices and maximum flavor.", color: "bg-emerald-50 border-emerald-200 text-emerald-900" },
    { name: "Chicken Shinwari Karahi", description: "Succulent chicken pieces prepared in the famous Shinwari style.", color: "bg-orange-50 border-orange-200 text-orange-900" },
    { name: "Aaloo Paratha & Lahori Channa", description: "A hearty breakfast combo of stuffed flatbread and chickpeas.", color: "bg-yellow-50 border-yellow-200 text-yellow-900" },
    { name: "Peshawari Qehwa", description: "Traditional green tea to complete your royal meal.", color: "bg-teal-50 border-teal-200 text-teal-900" },
  ]

  const { data: comments } = useSuspenseQuery(convexQuery(api.comments.list, {}))
  const addComment = useMutation(api.comments.add)

  const [newName, setNewName] = useState('')
  const [newContent, setNewContent] = useState('')
  const [newRating, setNewRating] = useState(5)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newName || !newContent) return
    setIsSubmitting(true)
    try {
      await addComment({
        name: newName,
        content: newContent,
        rating: newRating,
        foodScore: 5, // Default for now
      })
      setNewName('')
      setNewContent('')
      setNewRating(5)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#fffcf5] font-sans text-stone-900">
      {/* Sticky Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-200 py-4 px-6 flex justify-between items-center shadow-sm">
        <Link to="/" className="text-2xl font-serif font-black italic">
          Makhan <span className="text-red-600">Malai</span>
        </Link>
        <div className="hidden md:flex gap-8 items-center font-bold text-sm uppercase tracking-widest text-stone-600">
          <a href="#menu" className="hover:text-red-600 transition-colors">Specials</a>
          <Link to="/menu" className="hover:text-red-600 transition-colors">Full Menu</Link>
          <a href="#contact" className="hover:text-red-600 transition-colors">Location</a>
        </div>
        <div className="flex gap-4">
          <a href="tel:0505598443" className="bg-red-600 text-white px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-tighter hover:bg-red-700 transition-colors">
            Order Now
          </a>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="relative h-[85vh] flex items-center justify-center overflow-hidden pt-16">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=2000&auto=format&fit=crop" 
            alt="Delicious Indian Food" 
            className="w-full h-full object-cover brightness-40 scale-105 animate-pulse-slow"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-red-900/40 via-transparent to-[#fffcf5]"></div>
        </div>
        <div className="relative z-10 text-center text-white px-4">
          <span className="inline-block bg-amber-500 text-red-950 px-4 py-1 rounded-full text-sm font-bold uppercase tracking-widest mb-4 shadow-lg">Musaffah's Best Kept Secret</span>
          <h1 className="text-6xl md:text-8xl font-serif font-black mb-4 drop-shadow-2xl italic tracking-tight">
            Makhan <span className="text-amber-400">Malai</span>
          </h1>
          <p className="text-xl md:text-3xl font-medium mb-10 max-w-3xl mx-auto drop-shadow-md text-stone-100">
            A Royal Fusion of Pakistani Spice & North Indian Comfort
          </p>
          <div className="flex flex-wrap justify-center gap-6">
            <Link to="/menu" className="bg-red-600 hover:bg-red-700 text-white px-10 py-4 rounded-xl font-bold text-lg shadow-xl hover:shadow-red-500/20 transition-all transform hover:-translate-y-1">
              Explore the Menu
            </Link>
            <a href="#contact" className="bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border-2 border-white/40 px-10 py-4 rounded-xl font-bold text-lg transition-all transform hover:-translate-y-1">
              Find Our Table
            </a>
          </div>
        </div>
      </header>

      {/* Overview Section */}
      <section className="py-20 px-4 max-w-6xl mx-auto -mt-16 relative z-20">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="p-8 rounded-3xl bg-white shadow-xl border-b-4 border-red-500 transform hover:scale-105 transition-transform">
            <div className="bg-red-100 w-16 h-16 rounded-2xl flex items-center justify-center text-3xl mb-6 shadow-inner">⭐</div>
            <h3 className="text-2xl font-black mb-2 text-stone-800 tracking-tight">4.3 Stars</h3>
            <p className="text-stone-500 font-medium">Loved by 560+ guests for our authentic taste and warm service.</p>
          </div>
          <div className="p-8 rounded-3xl bg-white shadow-xl border-b-4 border-amber-500 transform hover:scale-105 transition-transform">
            <div className="bg-amber-100 w-16 h-16 rounded-2xl flex items-center justify-center text-3xl mb-6 shadow-inner">💰</div>
            <h3 className="text-2xl font-black mb-2 text-stone-800 tracking-tight">Affordable Luxury</h3>
            <p className="text-stone-500 font-medium">Fine dining flavors at Musaffah prices (AED 1–50 per person).</p>
          </div>
          <div className="p-8 rounded-3xl bg-white shadow-xl border-b-4 border-emerald-500 transform hover:scale-105 transition-transform">
            <div className="bg-emerald-100 w-16 h-16 rounded-2xl flex items-center justify-center text-3xl mb-6 shadow-inner">🌿</div>
            <h3 className="text-2xl font-black mb-2 text-stone-800 tracking-tight">Fresh & Green</h3>
            <p className="text-stone-500 font-medium">Vibrant vegan options and outdoor seating for the perfect vibe.</p>
          </div>
        </div>
      </section>

      {/* Menu Highlights */}
      <section id="menu" className="py-24 relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-red-100 rounded-full blur-3xl opacity-50 -mr-48 -mt-48"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-amber-100 rounded-full blur-3xl opacity-50 -ml-48 -mb-48"></div>

        <div className="max-w-6xl mx-auto px-4 relative z-10">
          <div className="text-center mb-16">
            <span className="text-red-600 font-black tracking-widest uppercase text-sm">Taste the Tradition</span>
            <h2 className="text-5xl md:text-6xl font-serif font-black mt-2 mb-4 text-stone-900 italic">Chef's <span className="text-red-600 underline decoration-amber-400">Specials</span></h2>
            <p className="text-stone-500 max-w-xl mx-auto text-lg font-medium">Each dish is crafted with heritage spices and a touch of modern magic.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {menuHighlights.map((item, i) => (
              <div key={i} className={`p-8 rounded-[2rem] border-2 shadow-lg hover:shadow-2xl transition-all group cursor-default ${item.color}`}>
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-2xl font-black leading-tight tracking-tight">{item.name}</h3>
                  <span className="text-2xl group-hover:scale-125 transition-transform">🔥</span>
                </div>
                <p className="opacity-80 text-sm leading-relaxed font-medium">{item.description}</p>
                <div className="mt-6 flex items-center gap-2 text-xs font-bold uppercase tracking-wider">
                   <span className="bg-white/50 px-3 py-1 rounded-full">Top Seller</span>
                   <span className="bg-white/50 px-3 py-1 rounded-full italic">Authentic</span>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-16 text-center">
             <Link to="/menu" className="bg-stone-900 text-white hover:bg-red-700 px-12 py-5 rounded-2xl font-black text-xl shadow-2xl transition-all transform hover:-translate-y-1">
               Browse Full Menu
             </Link>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section className="bg-red-700 py-24 text-white overflow-hidden relative">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
           <div className="grid grid-cols-6 gap-4 transform rotate-12 scale-150">
              {[...Array(24)].map((_, i) => (
                <div key={i} className="text-6xl font-black">MAKHAN MALAI</div>
              ))}
           </div>
        </div>
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-16 items-center relative z-10">
          <div>
            <h2 className="text-5xl font-serif font-black mb-6 italic leading-tight">Authentic flavors that tell a story.</h2>
            <p className="text-xl text-red-100 mb-8 font-medium">
              We bring the vibrant streets of Karachi and the royal kitchens of Peshawar straight to your plate in Musaffah. 
              Our spices are hand-picked, our ingredients are fresh, and our passion is unmatched.
            </p>
            <ul className="space-y-4 mb-10 text-lg">
              <li className="flex items-center gap-3">
                <span className="bg-amber-400 text-red-900 rounded-full p-1 text-sm">✔</span> Traditional Wood-Fired Karahis
              </li>
              <li className="flex items-center gap-3">
                <span className="bg-amber-400 text-red-900 rounded-full p-1 text-sm">✔</span> Secret Blend of 21 Spices
              </li>
              <li className="flex items-center gap-3">
                <span className="bg-amber-400 text-red-900 rounded-full p-1 text-sm">✔</span> Freshly Baked Tandoori Naan
              </li>
            </ul>
            <a href="tel:0505598443" className="bg-white text-red-700 px-10 py-4 rounded-xl font-black text-xl shadow-2xl inline-block hover:bg-amber-400 transition-colors">
              Call to Reserve
            </a>
          </div>
          <div className="grid grid-cols-2 gap-4">
             <img src="https://images.unsplash.com/photo-1541529086526-db283c563270?q=80&w=600&auto=format&fit=crop" className="rounded-3xl shadow-2xl transform -rotate-3" alt="Dish 1" />
             <img src="https://images.unsplash.com/photo-1514326640560-7d063ef2aed5?q=80&w=600&auto=format&fit=crop" className="rounded-3xl shadow-2xl transform translate-y-12 rotate-3" alt="Dish 2" />
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section id="reviews" className="py-24 bg-amber-50 relative overflow-hidden">
        <div className="max-w-6xl mx-auto px-4 relative z-10">
          <div className="text-center mb-16">
            <span className="text-red-600 font-black tracking-widest uppercase text-sm">Guest Stories</span>
            <h2 className="text-5xl font-serif font-black mt-2 mb-4 text-stone-900 italic">What People <span className="text-red-600 underline decoration-amber-400">Say</span></h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-20">
            {comments.map((comment) => (
              <div key={comment._id} className="bg-white p-8 rounded-[2rem] shadow-xl border-2 border-stone-100 flex flex-col h-full transform hover:-translate-y-2 transition-all">
                <div className="flex gap-1 text-amber-500 mb-4">
                  {[...Array(comment.rating)].map((_, i) => <span key={i}>⭐</span>)}
                </div>
                <p className="text-stone-700 font-medium italic mb-6 flex-1">"{comment.content}"</p>
                <div className="pt-6 border-t border-stone-100 mt-auto">
                  <div className="flex justify-between items-center text-xs font-black uppercase tracking-widest">
                    <span className="text-stone-900 font-bold">{comment.name}</span>
                    <div className="flex gap-4">
                      {comment.foodScore && <span className="text-red-600">Food: {comment.foodScore}/5</span>}
                      {comment.atmosphereScore && <span className="text-stone-400">Atm: {comment.atmosphereScore}/5</span>}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Comment Form */}
          <div className="max-w-2xl mx-auto bg-white p-10 rounded-[3rem] shadow-2xl border-4 border-amber-200">
            <h3 className="text-3xl font-serif font-black mb-6 text-stone-900 text-center italic">Leave a Review</h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-black uppercase tracking-widest text-stone-400 mb-2">Your Name</label>
                  <input 
                    type="text" 
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    className="w-full bg-stone-50 border-2 border-stone-100 rounded-xl px-4 py-3 focus:border-red-600 outline-none transition-colors"
                    placeholder="e.g. Ali Khan"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-black uppercase tracking-widest text-stone-400 mb-2">Rating</label>
                  <select 
                    value={newRating}
                    onChange={(e) => setNewRating(Number(e.target.value))}
                    className="w-full bg-stone-50 border-2 border-stone-100 rounded-xl px-4 py-3 focus:border-red-600 outline-none transition-colors"
                  >
                    <option value="5">5 Stars - Amazing</option>
                    <option value="4">4 Stars - Very Good</option>
                    <option value="3">3 Stars - Good</option>
                    <option value="2">2 Stars - Okay</option>
                    <option value="1">1 Star - Poor</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-black uppercase tracking-widest text-stone-400 mb-2">Your Comment</label>
                <textarea 
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  className="w-full bg-stone-50 border-2 border-stone-100 rounded-xl px-4 py-3 focus:border-red-600 outline-none transition-colors h-32 resize-none"
                  placeholder="Share your experience..."
                  required
                ></textarea>
              </div>
              <button 
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-red-600 text-white font-black py-4 rounded-xl shadow-xl hover:bg-red-700 transition-all disabled:bg-stone-300 transform active:scale-95"
              >
                {isSubmitting ? 'Posting...' : 'Post Review'}
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Contact & Location */}
      <section id="contact" className="py-32 px-4 max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div className="relative">
            <div className="absolute -left-10 -top-10 text-9xl text-stone-100 font-black -z-10 select-none">HELLO</div>
            <h2 className="text-5xl font-serif font-black mb-8 text-stone-900 italic tracking-tight">Visit Our <span className="text-red-600 underline decoration-amber-400">Kitchen</span></h2>
            <div className="space-y-8">
              <a href={googleMapsUrl} target="_blank" rel="noopener noreferrer" className="flex items-start gap-6 group">
                <div className="bg-red-100 text-red-600 p-4 rounded-2xl group-hover:bg-red-600 group-hover:text-white transition-colors">📍</div>
                <div>
                  <p className="text-sm font-black text-stone-400 uppercase tracking-widest mb-1">Location</p>
                  <p className="text-xl font-bold text-stone-800 leading-tight border-b-2 border-transparent group-hover:border-red-600 transition-all">3 Al Burouq St - Musaffah - ME12 - Abu Dhabi</p>
                </div>
              </a>
              <div className="flex items-start gap-6 group">
                <div className="bg-amber-100 text-amber-600 p-4 rounded-2xl group-hover:bg-amber-600 group-hover:text-white transition-colors">📞</div>
                <div>
                  <p className="text-sm font-black text-stone-400 uppercase tracking-widest mb-1">Contact</p>
                  <p className="text-xl font-bold text-stone-800 leading-tight">050 559 8443</p>
                </div>
              </div>
              <div className="flex items-start gap-6 group">
                <div className="bg-emerald-100 text-emerald-600 p-4 rounded-2xl group-hover:bg-emerald-600 group-hover:text-white transition-colors">🕒</div>
                <div>
                  <p className="text-sm font-black text-stone-400 uppercase tracking-widest mb-1">Hours</p>
                  <div className="text-xl font-bold text-stone-800">
                    <p>Open Daily</p>
                    <p className="text-emerald-600">7:00 AM – 12:00 AM</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-12 flex flex-wrap gap-4">
              <a 
                href="tel:0505598443" 
                className="bg-red-600 text-white px-10 py-4 rounded-xl font-black shadow-xl hover:bg-red-700 transition-colors inline-block text-center flex-1 min-w-[180px]"
              >
                Order Delivery
              </a>
              <a 
                href="tel:0505598443" 
                className="bg-stone-900 text-white px-10 py-4 rounded-xl font-black shadow-xl hover:bg-stone-800 transition-colors inline-block text-center flex-1 min-w-[180px]"
              >
                Call Now
              </a>
            </div>
          </div>
          <div className="relative">
             <div className="absolute inset-0 bg-amber-400 rounded-3xl transform rotate-3 -z-10"></div>
             <div className="bg-stone-200 aspect-[4/5] rounded-3xl flex items-center justify-center text-stone-400 overflow-hidden shadow-2xl relative">
                <img 
                  src="https://images.unsplash.com/photo-1526367790999-01507044a7f3?q=80&w=800&auto=format&fit=crop" 
                  alt="Food Photography" 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute bottom-6 left-6 right-6 bg-white/90 backdrop-blur-md p-6 rounded-2xl shadow-xl">
                   <p className="text-stone-900 font-black italic">"The best Karahi in the region, hands down."</p>
                   <p className="text-stone-400 text-sm font-bold mt-2">— Local Foodie</p>
                </div>
             </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-stone-900 text-white py-20 px-4 relative overflow-hidden">
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-12 relative z-10">
          <div>
            <p className="text-3xl font-serif font-black italic mb-6">Makhan <span className="text-amber-400">Malai</span></p>
            <p className="text-stone-400 font-medium leading-relaxed">
              Serving the authentic taste of the subcontinent with love and respect for tradition.
            </p>
          </div>
          <div className="flex flex-col gap-4">
             <p className="font-black uppercase tracking-widest text-sm text-amber-400 mb-2">Quick Links</p>
             <a href="#menu" className="hover:text-red-500 transition-colors font-bold">The Menu</a>
             <a href="#contact" className="hover:text-red-500 transition-colors font-bold">Location</a>
             <a href="#" className="hover:text-red-500 transition-colors font-bold">Gift Cards</a>
          </div>
          <div className="flex flex-col gap-4">
             <p className="font-black uppercase tracking-widest text-sm text-amber-400 mb-2">Social</p>
             <div className="flex gap-4">
                <a href="#" className="bg-white/10 p-3 rounded-full hover:bg-red-600 transition-all">FB</a>
                <a href="#" className="bg-white/10 p-3 rounded-full hover:bg-red-600 transition-all">IG</a>
                <a href="#" className="bg-white/10 p-3 rounded-full hover:bg-red-600 transition-all">TW</a>
             </div>
          </div>
        </div>
        <div className="border-t border-white/10 mt-16 pt-8 text-center text-stone-500 font-bold text-sm">
          <p>© 2024 Makhan Malai Restaurant. Crafted for Excellence.</p>
        </div>
      </footer>
    </div>
  )
}
