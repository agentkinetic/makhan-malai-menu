import { query, mutation, internalMutation } from "./_generated/server";
import { v } from "convex/values";

export const list = query({
  args: {},
  returns: v.array(
    v.object({
      _id: v.id("comments"),
      _creationTime: v.number(),
      name: v.string(),
      content: v.string(),
      rating: v.number(),
      foodScore: v.optional(v.number()),
      serviceScore: v.optional(v.number()),
      atmosphereScore: v.optional(v.number()),
    })
  ),
  handler: async (ctx) => {
    return await ctx.db.query("comments").order("desc").collect();
  },
});

export const add = mutation({
  args: {
    name: v.string(),
    content: v.string(),
    rating: v.number(),
    foodScore: v.optional(v.number()),
    serviceScore: v.optional(v.number()),
    atmosphereScore: v.optional(v.number()),
  },
  returns: v.id("comments"),
  handler: async (ctx, args) => {
    return await ctx.db.insert("comments", {
      name: args.name,
      content: args.content,
      rating: args.rating,
      foodScore: args.foodScore,
      serviceScore: args.serviceScore,
      atmosphereScore: args.atmosphereScore,
    });
  },
});

export const seed = internalMutation({
  args: {},
  returns: v.null(),
  handler: async (ctx) => {
    const existing = await ctx.db.query("comments").collect();
    if (existing.length > 0) return null;

    const initialReviews = [
      {
        name: "Happy Guest",
        content: "My friend suggested today this place for Al rehaman biryani. Exactly like karachi ki degi biryani.. Although spice level was less for us but it was our own preference having it very high spice.",
        rating: 5,
        foodScore: 5,
        atmosphereScore: 5
      },
      {
        name: "Desi Foodie",
        content: "The food here is sooooo gooodddd and yummy.🤤 Karachi biryani is the show stopper. 😍 their karahi and grills were also nice. The staff is nice to kids, and they are conscious about their food’s taste.",
        rating: 5,
        foodScore: 5,
        serviceScore: 5
      },
      {
        name: "Kabani Lover",
        content: "First time we are having chapli kabab and its very tasty. and Special Irani Chicken was also good. All over everything is good and must try items.",
        rating: 5,
        foodScore: 5,
        atmosphereScore: 4
      }
    ];

    for (const review of initialReviews) {
      await ctx.db.insert("comments", review);
    }
    return null;
  },
});
