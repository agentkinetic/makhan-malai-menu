import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  comments: defineTable({
    name: v.string(),
    content: v.string(),
    rating: v.number(), // Overall stars 1-5
    foodScore: v.optional(v.number()),
    serviceScore: v.optional(v.number()),
    atmosphereScore: v.optional(v.number()),
  }),
});
